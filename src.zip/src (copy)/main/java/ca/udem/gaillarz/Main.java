package ca.udem.gaillarz;

import ca.udem.gaillarz.formulation.*;
import ca.udem.gaillarz.io.InstanceReader;
import ca.udem.gaillarz.io.InvalidInstanceException;
import ca.udem.gaillarz.model.MKPInstance;

import java.io.IOException;
import java.util.*;

/**
 * Main class demonstrating the MKP formulation hierarchy.
 */
public class Main {
    public static void main(String[] args) {
        try {
            // Example instance content
            String instanceContent = """
                    2
                    5
                    7
                    6
                    5\t10
                    4\t8
                    3\t6
                    2\t5
                    1\t4
                    """;

            // ========== READ AND VISUALIZE INSTANCE ==========
            System.out.println("=" .repeat(60));
            System.out.println("MKP FORMULATION HIERARCHY DEMONSTRATION");
            System.out.println("=" .repeat(60));
            System.out.println();

            MKPInstance instance = InstanceReader.parseFromString(instanceContent, "example");
            System.out.println(instance.toDetailedString());
            System.out.println();
            System.out.println(instance.toTable());

            // ========== CREATE FORMULATION HIERARCHY ==========
            System.out.println("=" .repeat(60));
            System.out.println("CLASSIC FORMULATION");
            System.out.println("=" .repeat(60));
            System.out.println();

            ClassicFormulation classic = new ClassicFormulation(instance);
            System.out.println(classic.toMathematicalString());

            // Create a sample solution
            ClassicSolution classicSolution = new ClassicSolution(2, 5);
            classicSolution.assignItem(0, 0);  // Item 0 (w=5, p=10) to KS 0
            classicSolution.assignItem(0, 4);  // Item 4 (w=1, p=4) to KS 0
            classicSolution.assignItem(1, 1);  // Item 1 (w=4, p=8) to KS 1

            System.out.println("Sample Solution:");
            System.out.println(classicSolution.toDetailedString(instance));

            System.out.println("Objective: " + classic.computeObjectiveValue(classicSolution));
            System.out.println("Feasible: " + classic.isFeasible(classicSolution));
            System.out.println();

            // ========== L2 RELAXED FORMULATION ==========
            System.out.println("=" .repeat(60));
            System.out.println("L2 RELAXED FORMULATION");
            System.out.println("=" .repeat(60));
            System.out.println();

            L2RelaxedFormulation l2 = classic.toL2Formulation();
            System.out.println(l2.toMathematicalString());

            // Convert classic solution to L2
            L2Solution l2Solution = L2Solution.fromClassicSolution(classicSolution, 5);
            System.out.println("Converted L2 Solution:");
            System.out.println(l2Solution.toItemSelectionString());
            System.out.println(l2Solution.toAssignmentString());

            System.out.println("L2 Objective: " + l2.computeObjectiveValue(l2Solution));
            System.out.println("L2 Feasible: " + l2.isFeasible(l2Solution));
            System.out.println();

            // Show Lagrangian relaxation
            double[] mu = {2.0, 1.5, 1.0, 0.5, 0.0};
            System.out.println(l2.toLagrangianString(mu));

            // ========== DANTZIG-WOLFE MASTER FORMULATION ==========
            System.out.println("=" .repeat(60));
            System.out.println("DANTZIG-WOLFE MASTER FORMULATION");
            System.out.println("=" .repeat(60));
            System.out.println();

            DantzigWolfeMaster dwMaster = l2.toDantzigWolfeFormulation();

            // Generate some initial patterns
            System.out.println("Generating initial patterns...");
            generateInitialPatterns(dwMaster, instance);

            System.out.println(dwMaster.toStructureString());
            System.out.println();
            System.out.println(dwMaster.toPatternsString());

            // ========== CONVERSION DEMONSTRATION ==========
            System.out.println("=" .repeat(60));
            System.out.println("CONVERSION DEMONSTRATION");
            System.out.println("=" .repeat(60));
            System.out.println();

            // Create a DW solution
            Map<Pattern, Double> patternValues = new HashMap<>();

            // Find patterns that match our classic solution
            Pattern p0ForSolution = findOrCreatePattern(dwMaster.getPatternsP0(),
                    Set.of(0, 4), instance, dwMaster, true);
            Pattern pi0ForSolution = findOrCreatePattern(dwMaster.getPatternsPI(0),
                    Set.of(0, 4), instance, null, false);
            Pattern pi1ForSolution = findOrCreatePattern(dwMaster.getPatternsPI(1),
                    Set.of(1), instance, null, false);

            if (p0ForSolution != null && pi0ForSolution != null && pi1ForSolution != null) {
                patternValues.put(p0ForSolution, 1.0);
                patternValues.put(pi0ForSolution, 1.0);
                patternValues.put(pi1ForSolution, 1.0);

                DWSolution dwSolution = new DWSolution(patternValues, 5);
                System.out.println("DW Solution:");
                System.out.println(dwSolution.toPatternValuesString());

                // Convert DW → L2
                L2Solution derivedL2 = dwMaster.toL2Solution(dwSolution);
                System.out.println("Derived L2 Solution (from DW):");
                System.out.println(derivedL2.toItemSelectionString());

                // Convert L2 → Classic (if integer)
                if (derivedL2.isInteger()) {
                    ClassicSolution derivedClassic = derivedL2.toClassicSolution();
                    System.out.println("Derived Classic Solution (from L2):");
                    System.out.println(derivedClassic.toMatrixString());

                    // Verify objectives match
                    System.out.println("\nObjective Comparison:");
                    System.out.println("  Classic:  " + classic.computeObjectiveValue(derivedClassic));
                    System.out.println("  L2:       " + l2.computeObjectiveValue(derivedL2));
                    System.out.println("  DW:       " + dwMaster.computeObjectiveValue(dwSolution));
                }
            }

            System.out.println("\n" + "=" .repeat(60));
            System.out.println("DEMONSTRATION COMPLETE");
            System.out.println("=" .repeat(60));

        } catch (InvalidInstanceException e) {
            System.err.println("Error parsing instance: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Generate initial patterns for all pattern pools.
     */
    private static void generateInitialPatterns(DantzigWolfeMaster dwMaster, MKPInstance instance) {
        // Add empty pattern to all pools
        Pattern empty = Pattern.empty(instance.getNumItems());
        try {
            dwMaster.addPatternP0(empty);
        } catch (FormulationException e) {
            // Ignore if already added
        }

        for (int i = 0; i < instance.getNumKnapsacks(); i++) {
            try {
                dwMaster.addPatternPI(i, empty);
            } catch (FormulationException e) {
                // Ignore
            }
        }

        // Add single-item patterns
        for (int j = 0; j < instance.getNumItems(); j++) {
            Pattern single = Pattern.singleItem(j, instance);

            // Try to add to P0
            if (single.isFeasible(instance.getTotalCapacity())) {
                try {
                    dwMaster.addPatternP0(single);
                } catch (FormulationException e) {
                    // Ignore
                }
            }

            // Try to add to each PI
            for (int i = 0; i < instance.getNumKnapsacks(); i++) {
                if (single.isFeasible(instance.getKnapsack(i).getCapacity())) {
                    try {
                        dwMaster.addPatternPI(i, single);
                    } catch (FormulationException e) {
                        // Ignore
                    }
                }
            }
        }

        // Add some multi-item patterns for P0 and PI
        // Pattern {0, 4} for our example solution
        Set<Integer> items04 = new HashSet<>();
        items04.add(0);
        items04.add(4);
        Pattern p04 = Pattern.fromItemIds(items04, instance);

        if (p04.isFeasible(instance.getTotalCapacity())) {
            try {
                dwMaster.addPatternP0(p04);
            } catch (FormulationException e) {
                // Ignore
            }
        }
        if (p04.isFeasible(instance.getKnapsack(0).getCapacity())) {
            try {
                dwMaster.addPatternPI(0, p04);
            } catch (FormulationException e) {
                // Ignore
            }
        }
    }

    /**
     * Find a pattern with the specified items, or create and add it.
     */
    private static Pattern findOrCreatePattern(List<Pattern> patterns, Set<Integer> itemIds,
                                                MKPInstance instance, DantzigWolfeMaster dwMaster,
                                                boolean isP0) {
        for (Pattern p : patterns) {
            if (p.getItemIds().equals(itemIds)) {
                return p;
            }
        }

        // Create new pattern
        Pattern newPattern = Pattern.fromItemIds(itemIds, instance);

        if (dwMaster != null && isP0) {
            try {
                dwMaster.addPatternP0(newPattern);
                return newPattern;
            } catch (FormulationException e) {
                return null;
            }
        }

        return null;
    }
}
