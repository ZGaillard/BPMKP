package ca.udem.gaillarz.formulation;

import java.util.*;

/**
 * Represents a solution to the Dantzig-Wolfe master formulation.
 * Contains y_a (pattern values) and s_j (dual cut values).
 */
public class DWSolution {
    private static final double TOLERANCE = 1e-5;

    private final Map<Pattern, Double> patternValues;  // y_a values
    private final Map<Integer, Double> dualCutValues;  // s_j values
    private final int numItems;

    /**
     * Create DW solution from pattern and dual cut values.
     *
     * @param patternValues  Map from patterns to their y_a values
     * @param dualCutValues  Map from item indices to their s_j values
     */
    public DWSolution(Map<Pattern, Double> patternValues,
                      Map<Integer, Double> dualCutValues) {
        if (patternValues == null) {
            throw new IllegalArgumentException("Pattern values cannot be null");
        }
        if (dualCutValues == null) {
            throw new IllegalArgumentException("Dual cut values cannot be null");
        }

        this.patternValues = new HashMap<>(patternValues);
        this.dualCutValues = new HashMap<>(dualCutValues);
        this.numItems = dualCutValues.size();
    }

    /**
     * Create solution with zero dual cuts.
     *
     * @param patternValues Map from patterns to their y_a values
     * @param numItems      Number of items
     */
    public DWSolution(Map<Pattern, Double> patternValues, int numItems) {
        this.patternValues = new HashMap<>(patternValues);
        this.dualCutValues = new HashMap<>();
        for (int j = 0; j < numItems; j++) {
            dualCutValues.put(j, 0.0);
        }
        this.numItems = numItems;
    }

    /**
     * Get y_a value for a pattern.
     *
     * @param pattern Pattern to query
     * @return y_a value, or 0 if pattern not in solution
     */
    public double getPatternValue(Pattern pattern) {
        return patternValues.getOrDefault(pattern, 0.0);
    }

    /**
     * Get s_j value for an item.
     *
     * @param itemId Item index
     * @return s_j value
     */
    public double getDualCutValue(int itemId) {
        return dualCutValues.getOrDefault(itemId, 0.0);
    }

    /**
     * Get all patterns with non-zero values.
     *
     * @return Set of active patterns
     */
    public Set<Pattern> getActivePatterns() {
        Set<Pattern> active = new HashSet<>();
        for (Map.Entry<Pattern, Double> entry : patternValues.entrySet()) {
            if (Math.abs(entry.getValue()) > TOLERANCE) {
                active.add(entry.getKey());
            }
        }
        return active;
    }

    /**
     * Get all patterns and their values.
     *
     * @return Unmodifiable map of pattern values
     */
    public Map<Pattern, Double> getPatternValues() {
        return Collections.unmodifiableMap(patternValues);
    }

    /**
     * Get all dual cut values.
     *
     * @return Unmodifiable map of dual cut values
     */
    public Map<Integer, Double> getDualCutValues() {
        return Collections.unmodifiableMap(dualCutValues);
    }

    /**
     * @return Number of items
     */
    public int getNumItems() {
        return numItems;
    }

    /**
     * Check if pattern values are integer (within tolerance).
     *
     * @return true if all pattern values are approximately 0 or 1
     */
    public boolean arePatternValuesInteger() {
        for (double value : patternValues.values()) {
            if (!isInteger(value)) return false;
        }
        return true;
    }

    /**
     * Check if dual cuts are integer.
     *
     * @return true if all dual cuts are approximately integer
     */
    public boolean areDualCutsInteger() {
        for (double value : dualCutValues.values()) {
            if (!isInteger(value)) return false;
        }
        return true;
    }

    /**
     * Check if entire solution is integer.
     *
     * @return true if both pattern values and dual cuts are integer
     */
    public boolean isInteger() {
        return arePatternValuesInteger() && areDualCutsInteger();
    }

    private boolean isInteger(double value) {
        return Math.abs(value - Math.round(value)) < TOLERANCE;
    }

    @Override
    public String toString() {
        int totalPatterns = patternValues.size();
        int activePatterns = getActivePatterns().size();
        return String.format("DWSolution(active_patterns=%d/%d, integer=%s)",
                activePatterns, totalPatterns, isInteger() ? "yes" : "no");
    }

    /**
     * Show pattern values in a table.
     *
     * @return Table string representation
     */
    public String toPatternValuesString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Active Patterns (y_a > 0):\n");
        sb.append("┌────────┬──────────────┬────────┬──────────┬──────────┐\n");
        sb.append("│  ID    │    Items     │ Profit │   y_a    │ Integer? │\n");
        sb.append("├────────┼──────────────┼────────┼──────────┼──────────┤\n");

        List<Pattern> activePatterns = new ArrayList<>(getActivePatterns());
        activePatterns.sort(Comparator.comparingInt(Pattern::getId));

        int count = 0;
        for (Pattern p : activePatterns) {
            if (count >= 20) {
                sb.append("│  ...   │     ...      │   ...  │    ...   │    ...   │\n");
                break;
            }
            double value = patternValues.get(p);
            String intChar = isInteger(value) ? "✓" : "✗";
            String itemsStr = p.getItemIds().toString();
            if (itemsStr.length() > 12) {
                itemsStr = itemsStr.substring(0, 9) + "...";
            }
            sb.append(String.format("│ %6d │ %-12s │ %6.1f │  %6.3f  │    %s     │\n",
                    p.getId(), itemsStr, p.getTotalProfit(), value, intChar));
            count++;
        }

        sb.append("└────────┴──────────────┴────────┴──────────┴──────────┘\n");
        return sb.toString();
    }

    /**
     * Show dual cut values.
     *
     * @return Table string representation
     */
    public String toDualCutsString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Dual Cuts (s_j):\n");
        sb.append("┌──────┬──────────┬──────────┐\n");
        sb.append("│ Item │   s_j    │ Integer? │\n");
        sb.append("├──────┼──────────┼──────────┤\n");

        List<Integer> items = new ArrayList<>(dualCutValues.keySet());
        Collections.sort(items);

        for (int j = 0; j < Math.min(items.size(), 20); j++) {
            int itemId = items.get(j);
            double value = dualCutValues.get(itemId);
            String intChar = isInteger(value) ? "✓" : "✗";
            sb.append(String.format("│ %4d │  %6.3f  │    %s     │\n", itemId, value, intChar));
        }
        if (items.size() > 20) {
            sb.append("│  ... │    ...   │    ...   │\n");
        }

        sb.append("└──────┴──────────┴──────────┘\n");
        return sb.toString();
    }

    /**
     * Combined detailed view.
     *
     * @param master DantzigWolfeMaster for computing derived values
     * @return Detailed string representation
     */
    public String toDetailedString(DantzigWolfeMaster master) {
        StringBuilder sb = new StringBuilder();
        int width = 44;
        String border = "─".repeat(width - 2);

        sb.append("┌").append(border).append("┐\n");
        sb.append(String.format("│ %-" + (width - 4) + "s │\n", "Dantzig-Wolfe Solution"));
        sb.append("├").append(border).append("┤\n");

        // Summary
        int totalPatterns = patternValues.size();
        int activePatterns = getActivePatterns().size();
        sb.append(String.format("│ %-" + (width - 4) + "s │\n",
                String.format("Pattern values: %d active / %d total", activePatterns, totalPatterns)));
        sb.append(String.format("│ %-" + (width - 4) + "s │\n",
                String.format("Pattern values integer: %s", arePatternValuesInteger() ? "YES" : "NO")));
        sb.append(String.format("│ %-" + (width - 4) + "s │\n",
                String.format("Dual cuts integer: %s", areDualCutsInteger() ? "YES" : "NO")));
        sb.append(String.format("│ %-" + (width - 4) + "s │\n",
                String.format("Overall integer: %s", isInteger() ? "YES" : "NO")));

        sb.append("├").append(border).append("┤\n");

        // Derived item selections
        sb.append(String.format("│ %-" + (width - 4) + "s │\n", "Derived item selections (t_j):"));
        for (int j = 0; j < Math.min(numItems, 5); j++) {
            double tj = master.computeItemSelection(this, j);
            String intChar = Math.abs(tj - Math.round(tj)) < TOLERANCE ? "✓" : "✗";
            sb.append(String.format("│   t[%d] = %.3f %s%-" + (width - 21) + "s │\n",
                    j, tj, intChar, "(from P_0 patterns)"));
        }
        if (numItems > 5) {
            sb.append(String.format("│   %-" + (width - 7) + "s │\n", "..."));
        }

        sb.append("└").append(border).append("┘\n");

        return sb.toString();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        DWSolution that = (DWSolution) o;
        return Objects.equals(patternValues, that.patternValues) &&
               Objects.equals(dualCutValues, that.dualCutValues);
    }

    @Override
    public int hashCode() {
        return Objects.hash(patternValues, dualCutValues);
    }
}

